[![Build Status](https://travis-ci.org/SYOUNG9836/kadmin.svg?branch=main)](https://travis-ci.com/github/SYOUNG9836/kadmin)

# kadmin

For more on using this R package, see the GitHub repository for the [kadmin package](https://github.com/SYOUNG9836/kadmin). The Administrative districts of Korea shapefile are included in this package `kadmin`. the `*rda` file `do.rda`, `sgg.rda` and `emd.rda` are around 68 MB in size.

 
## Installation
kadmin
```
install.packages("kadmin", repos='https://SYOUNG9836.github.io/drat/', type='source')
```

